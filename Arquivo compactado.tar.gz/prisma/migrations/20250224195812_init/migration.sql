-- AlterTable
ALTER TABLE "Biometria" ALTER COLUMN "dadosBiometricos" SET DATA TYPE TEXT;
