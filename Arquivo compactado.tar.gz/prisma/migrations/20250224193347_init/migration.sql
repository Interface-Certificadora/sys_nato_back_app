/*
  Warnings:

  - Added the required column `atualizadoEm` to the `Biometria` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Biometria" ADD COLUMN     "atualizadoEm" TIMESTAMP(3) NOT NULL;
